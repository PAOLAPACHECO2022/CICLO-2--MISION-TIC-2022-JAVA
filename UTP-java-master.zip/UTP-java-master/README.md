# Hola Tripulante... Aquí encontrarás una guía que te ayudará a resolver los retos de ciclo 2. 
Dentro de cada reto encontrarás las clases en java y el modelo de lo que debes subir a iMaster en un archivo.txt.
Recuerda no descuidar las clases y procura entender y estudiar los temas que consideres pertinente para apropiarte de los retos.
